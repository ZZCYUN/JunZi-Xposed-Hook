package junzi.xposed.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;

public class HookInit implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(final LoadPackageParam lpparam) throws Throwable {
         //hook部分暂不开源
    }
}
